
const SCOPE_DICT = require('./policy.scopedict.json');
const TYPE_SCOPE_MAP = require('./policy.typescopes.json');

module.exports = {
  extends: ['@commitlint/config-conventional'],
  plugins: [require('./commitlint.breaking-plugin.js')],
  rules: {
    'type-enum': [2, 'always', [
      'feat','fix','docs','style','refactor','perf','test','build','ci','chore','revert',
      'design','deps','security','infra','release','i18n','l10n','ux','ui','ops','hotfix'
    ]],
    'type-case': [2, 'always', 'lower-case'],
    'scope-required-except-release': [2, 'always'],
    'scope-max-length': [2, 'always', 24],
    'scope-dictionary': [2, 'always', SCOPE_DICT],
    'type-scope-map': [2, 'always', TYPE_SCOPE_MAP],
    'subject-empty': [2, 'never'],
    'subject-full-stop': [2, 'never'],
    'subject-min-length': [2, 'always', 8],
    'header-max-length': [2, 'always', 72],
    'breaking-consistency': [2, 'always'],
    'breaking-scope-only': [2, 'always', ['api/*','infra/*']],
    'issue-key-footer-only': [2, 'always', {
      regex: '\\b(?:PF|LD|[A-Z][A-Z0-9]{1,9})-\\d{1,6}\\b',
      footer_prefixes: ['JIRA','Closes','Fixes','Resolves','Refs','이슈','닫음','해결']
    }],
  },
};
