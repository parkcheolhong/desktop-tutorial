# CHANGELOG 고급 정책 (커스터마이즈형)

- 날짜 형식: YYYY.MM.DD
- 카테고리: Breaking / UI / UX / Added / Changed / Fixed / Performance / Security / Docs / Chore
- Notes/Contributors 템플릿 옵션은 policy.changelog.json에서 설정
