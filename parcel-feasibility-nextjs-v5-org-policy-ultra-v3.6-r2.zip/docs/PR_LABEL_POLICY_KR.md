# PR 라벨 정책

- 필수 접두어: type:, area:, impact:
- 허용 값은 policy.labels.json에서 관리합니다.
