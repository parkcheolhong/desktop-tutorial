#!/usr/bin/env bash
set -euo pipefail
OWNER="${1:-}"; REPO="${2:-}"
if [[ -z "$OWNER" || -z "$REPO" ]]; then echo "Usage: $0 <owner> <repo>"; exit 1; fi
export CHECKS="${CHECKS:-build,unit-test,e2e-chrome,e2e-firefox,e2e-webkit,label-policy,release-guard}"
chmod +x scripts/gh-create-ruleset.sh || true
scripts/gh-create-ruleset.sh "$OWNER" "$REPO" "$CHECKS"
