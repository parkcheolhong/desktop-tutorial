#!/usr/bin/env bash
set -euo pipefail
CFG="policy.changelog.json"
usage() { echo "Usage: $0 <vX.Y.Z> --issue-key KEY [--date YYYY.MM.DD] [--dry-run] [--gh-release] [--push] [--notes FILE] [--no-contrib] [--contrib-mode all|pr-authors|pr-mergers] [--contrib-domain @company.com[,..]] [--include-bots]"; }
VER="${1:-}"; shift || true; [[ -z "$VER" || ! "$VER" =~ ^v[0-9]+\.[0-9]+\.[0-9]+([-.].*)?$ ]] && { usage; exit 1; }

DATE_FMT="YYYY.MM.DD"; ORDER=("Breaking" "UI" "UX" "Added" "Changed" "Fixed" "Performance" "Security" "Docs" "Chore")
declare -A LABELMAP=(); NOTES_HEADING="Notes"; CONTRIB_HEADING="Contributors"; CONTRIB_FORMAT="table"; CONTRIB_SHOW_EMAILS="false"; CONTRIB_LINK_HANDLES="true"; CONTRIB_MIN_COMMITS=1
if command -v jq >/dev/null 2>&1 && [[ -f "$CFG" ]]; then
  DATE_FMT=$(jq -r '.date_format // "YYYY.MM.DD"' "$CFG"); mapfile -t ORDER < <(jq -r '.section_order[]' "$CFG")
  while IFS=$'\t' read -r k v; do LABELMAP["$k"]="$v"; done < <(jq -r '.labels_to_categories | to_entries[] | "\(.key)\t\(.value)"' "$CFG")
  NOTES_HEADING=$(jq -r '.notes_heading // "Notes"' "$CFG"); CONTRIB_HEADING=$(jq -r '.contributors.heading // "Contributors"' "$CFG")
  CONTRIB_FORMAT=$(jq -r '.contributors.format // "table"' "$CFG"); CONTRIB_SHOW_EMAILS=$(jq -r '.contributors.show_emails // false' "$CFG")
  CONTRIB_LINK_HANDLES=$(jq -r '.contributors.link_handles // true' "$CFG"); CONTRIB_MIN_COMMITS=$(jq -r '.contributors.min_commits // 1' "$CFG")
fi

ISSUE_KEY=""; GHREL=0; PUSH=0; DRY=0; NOTES=""; CONTRIB=1; DATE_IN=""; CONTRIB_MODE="all"; CONTRIB_DOMAIN=""; INCLUDE_BOTS=0
while [[ $# -gt 0 ]]; do case "$1" in
  --issue-key) ISSUE_KEY="${2:-}"; shift 2;; --date) DATE_IN="${2:-}"; shift 2;;
  --gh-release) GHREL=1; shift;; --push) PUSH=1; shift;; --dry-run) DRY=1; shift;;
  --notes) NOTES="${2:-}"; shift 2;; --no-contrib) CONTRIB=0; shift;;
  --contrib-mode) CONTRIB_MODE="${2:-all}"; shift 2;; --contrib-domain) CONTRIB_DOMAIN="${2:-}"; shift 2;;
  --include-bots) INCLUDE_BOTS=1; shift;; *) echo "Unknown arg: $1"; usage; exit 1;; esac; done
[[ -z "$ISSUE_KEY" ]] && { echo "ERROR: --issue-key is required."; exit 1; }
DATE="${DATE_IN:-$([[ "$DATE_FMT" == "YYYY.MM.DD" ]] && date +%Y.%m.%d || date +%F)}"
git diff-index --quiet HEAD -- || { echo "ERROR: working tree not clean."; exit 1; }
LAST_TAG=$(git describe --tags --abbrev=0 2>/dev/null || echo ""); RANGE=""; [[ -n "$LAST_TAG" ]] && RANGE="${LAST_TAG}..HEAD" || RANGE="--all"
COMMITS=$(git log ${RANGE} --pretty=format:'%H%x00%s%x00%b%x00==END==' | tr -d '\r')
declare -A BUCKETS; for c in "${ORDER[@]}"; do BUCKETS["$c"]=''; done; declare -A CONTRIB_COUNT
add_b() { local c="$1"; local t="$2"; BUCKETS["$c"]+="$t"$'\n'; }
map_labels() { local pr="$1"; command -v gh >/dev/null 2>&1 || { echo ""; return; }; local labels=$(gh pr view "$pr" --json labels --jq '.labels[].name' 2>/dev/null || true); local pick=""; while read -r lbl; do lbl=${lbl,,}; for k in "${!LABELMAP[@]}"; do [[ "${k,,}" == "$lbl" ]] && { pick="${LABELMAP[$k]}"; break; }; done; [[ -n "$pick" ]] && break; done <<< "$labels"; echo "$pick"; }
rec_contrib() { local n="$1"; local e="$2"; local key="$n<$e>"; CONTRIB_COUNT["$key"]=$(( ${CONTRIB_COUNT["$key"]:-0} + 1 )); }

while IFS= read -r line; do
  [[ "$line" == "==END==" ]] && continue; IFS=$'\0' read -r h s b <<<"$line"; [[ "$s" =~ ^release:\  ]] && continue
  PR=""; [[ "$s" =~ \#([0-9]+) ]] && PR="${BASH_REMATCH[1]}"; [[ -z "$PR" && "$b" =~ Pull-Request:\ \#([0-9]+) ]] && PR="${BASH_REMATCH[1]}"
  type="chore"; text="$s"; bang=""; [[ "$s" =~ ^([a-z]+)(\([^)]+\))?(!)?:\ (.+)$ ]] && { type="${BASH_REMATCH[1]}"; bang="${BASH_REMATCH[3]}"; text="${BASH_REMATCH[4]}"; }
  bullet="- ${text} (${h:0:7})"
  if [[ -n "$bang" || "$b" =~ BREAKING\ CHANGE: ]]; then add_b "Breaking" "$bullet"; continue; fi
  CAT=""; [[ -n "$PR" ]] && CAT="$(map_labels "$PR")"; [[ -n "$CAT" ]] && { add_b "$CAT" "$bullet"; continue; }
  case "$type" in feat) add_b "Added" "$bullet";; fix) add_b "Fixed" "$bullet";; refactor) add_b "Changed" "$bullet";;
    perf) add_b "Performance" "$bullet";; security) add_b "Security" "$bullet";; docs) add_b "Docs" "$bullet";; ui) add_b "UI" "$bullet";; ux) add_b "UX" "$bullet";;
    build|ci|deps|chore|revert|infra|design) add_b "Chore" "$bullet";; *) add_b "Changed" "$bullet";; esac
done <<< "$COMMITS"

# Contributors (simple: shortlog)
if [[ $CONTRIB -eq 1 ]]; then
  while IFS= read -r line; do name=$(echo "$line" | sed 's/[[:space:]]*<.*$//'); email=$(echo "$line" | sed -n 's/^.*<\([^>]*\)>.*/\1/p'); rec_contrib "$name" "$email"; done < <(git shortlog -sne ${RANGE} | sed 's/^[ ]*[0-9]\+[ \t]\+//')
fi

SECTION="## ${VER} - ${DATE}\n\n"; for c in "${ORDER[@]}"; do cont="${BUCKETS[$c]}"; [[ -n "$cont" ]] && SECTION+="### ${c}\n${cont}\n"; done
[[ -n "$NOTES" && -f "$NOTES" ]] && SECTION+="### ${NOTES_HEADING}\n$(cat "$NOTES")\n\n"
if [[ $CONTRIB -eq 1 && ${#CONTRIB_COUNT[@]} -gt 0 ]]; then
  SECTION+="### ${CONTRIB_HEADING}\n| Contributor | Commits |\n|---|---:|\n"
  { for k in "${!CONTRIB_COUNT[@]}"; do echo -e "${CONTRIB_COUNT[$k]}\t$k"; done; } | sort -rn | while IFS=$'\t' read -r cnt key; do name="${key%%<*}"; SECTION+="| ${name} | ${cnt} |\n"; done
  SECTION+="\n"
fi
[[ $DRY -eq 1 ]] && { echo -e "$SECTION"; exit 0; }
[[ ! -f CHANGELOG.md ]] && echo "# Changelog" > CHANGELOG.md
awk -v s="$SECTION" 'NR==1{print; print ""; print s; nextfile} {print}' CHANGELOG.md > CHANGELOG.tmp || true
grep -q "^## ${VER} - ${DATE}$" CHANGELOG.tmp || { echo "# Changelog" > CHANGELOG.tmp; echo "" >> CHANGELOG.tmp; echo -e "$SECTION" >> CHANGELOG.tmp; tail -n +2 CHANGELOG.md >> CHANGELOG.tmp; }
mv CHANGELOG.tmp CHANGELOG.md
git add CHANGELOG.md; git commit -m "release: ${VER}" -m "JIRA: ${ISSUE_KEY}"; git tag -a "${VER}" -m "${VER}" -m "$SECTION"
[[ $GHREL -eq 1 ]] && command -v gh >/dev/null 2>&1 && gh release create "${VER}" --notes "$SECTION" || true
[[ $PUSH -eq 1 ]] && { git push && git push --tags; } || true
echo "OK: release commit/tag ${VER} + CHANGELOG updated."
