#!/usr/bin/env bash
set -euo pipefail
echo "== Preflight: CHANGELOG (release-only) =="; bash scripts/check-changelog-release.sh || exit $?
echo "== Preflight: CHANGELOG format =="; bash scripts/check-changelog-format.sh || exit $?
