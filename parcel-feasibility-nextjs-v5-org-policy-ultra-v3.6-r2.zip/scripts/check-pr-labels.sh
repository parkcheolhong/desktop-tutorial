#!/usr/bin/env bash
set -euo pipefail
CFG="policy.labels.json"
command -v jq >/dev/null 2>&1 || { echo "ERROR: jq required"; exit 1; }
command -v gh >/dev/null 2>&1 || { echo "ERROR: gh required"; exit 1; }
PR_NUMBER="${PR_NUMBER:-}"; [[ -z "$PR_NUMBER" ]] && { echo "ERROR: PR_NUMBER env required"; exit 1; }
labels=$(gh pr view "$PR_NUMBER" --json labels --jq '.labels[].name' || true)
required=($(jq -r '.required_prefixes[]' "$CFG"))
case_insensitive=$(jq -r '.case_insensitive // true' "$CFG")
allowed=$(jq -c '.allowed' "$CFG")
norm() { [[ "$case_insensitive" == "true" ]] && echo "$1" | tr '[:upper:]' '[:lower:]' || echo "$1"; }
declare -A present
declare -A values
while read -r lbl; do l=$(norm "$lbl"); for pref in "${required[@]}"; do pn=$(norm "$pref"); [[ "$l" == "$pn"* ]] && { present["$pn"]=1; v="${l#$pn}"; values["$pn"]="${values[$pn]} $v"; }; done; done <<< "$labels"
err=0
for pref in "${required[@]}"; do pn=$(norm "$pref"); [[ -z "${present[$pn]:-}" ]] && { echo "ERROR: missing label with prefix '${pref}'"; err=$((err+1)); }; done
for pref in "${required[@]}"; do
  pn=$(norm "$pref"); alist=$(echo "$allowed" | jq -r --arg p "$pref" '.[$p] // empty | @sh' | tr -d "'")
  [[ -z "$alist" ]] && continue
  IFS=' ' read -r -a allowed_vals <<< "$alist"
  for v in ${values[$pn]:-}; do ok=0; for a in "${allowed_vals[@]}"; do [[ "$(norm "$v")" == "$(norm "$a")" ]] && { ok=1; break; }; done; [[ $ok -eq 0 ]] && { echo "ERROR: label '${pref}${v}' not allowed"; err=$((err+1)); }; done
done
[[ $err -gt 0 ]] && { echo "Label policy failed ($err error)"; exit 2; } || echo "OK"
