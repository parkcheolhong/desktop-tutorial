#!/usr/bin/env bash
set -euo pipefail
OWNER="${1:-}"; REPO="${2:-}"; CHECKS="${3:-build,unit-test,e2e-chrome,e2e-firefox,e2e-webkit,label-policy,release-guard}"
if [[ -z "$OWNER" || -z "$REPO" ]]; then echo "Usage: $0 <owner> <repo> [checks]"; exit 1; fi
# Apply classic branch protection on default branch with required checks
DEF=$(gh api /repos/$OWNER/$REPO --jq .default_branch)
echo "Applying classic protection on $DEF with checks: $CHECKS"
CTX=$(python - <<PY
import os,sys,json
print(json.dumps({"contexts": os.environ.get("CHECKS","").split(",")}))
PY
)
gh api -X PUT /repos/$OWNER/$REPO/branches/$DEF/protection \
  -H "Accept: application/vnd.github+json" \
  -f required_status_checks="$(echo "$CTX")" \
  -F enforce_admins=true \
  -F required_pull_request_reviews='{"required_approving_review_count":1}' \
  -F restrictions= \
  >/dev/null
echo "Protection applied."
