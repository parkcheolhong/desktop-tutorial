#!/usr/bin/env bash
set -euo pipefail
REL_SUBJ=$(git log -1 --grep '^release:\s' --pretty=%s 2>/dev/null || echo "")
[[ -z "$REL_SUBJ" ]] && { echo "INFO: no release commit on HEAD; skip"; exit 0; }
VER=$(echo "$REL_SUBJ" | sed -n 's/^release:[[:space:]]*\(v[0-9][0-9]*\.[0-9][0-9]*\.[0-9][0-9]*[^ ]*\).*$/\1/p')
[[ -z "$VER" ]] && { echo "ERROR: release subject lacks semver 'vX.Y.Z'"; exit 1; }
[[ ! -f CHANGELOG.md ]] && { echo "ERROR: CHANGELOG.md not found"; exit 1; }
head -n 100 CHANGELOG.md | grep -E "^(##|###)?\s*\[*${VER}\]*\b" >/dev/null || { echo "ERROR: top section missing ${VER}"; exit 1; }
awk -v ver="$VER" '
BEGIN{f=0} $0 ~ "^(##|###)?[[:space:]]*\\[*"ver"\\]*" {f=1;next}
f==1 && $0 ~ "^(##|###)[[:space:]]" {exit}
f==1{print}
' CHANGELOG.md > ._sec.tmp
grep -qE "^\s*[-*+]\s+" ._sec.tmp || { echo "ERROR: ${VER} section has no bullet items"; rm -f ._sec.tmp; exit 1; }
rm -f ._sec.tmp; echo "OK"
