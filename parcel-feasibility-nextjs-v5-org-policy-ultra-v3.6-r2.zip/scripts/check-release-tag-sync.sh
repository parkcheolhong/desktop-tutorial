#!/usr/bin/env bash
set -euo pipefail
REL=$(git log -1 --grep '^release:\s' --pretty=%s 2>/dev/null || echo "")
[[ -z "$REL" ]] && { echo "INFO: no release commit; skip"; exit 0; }
VER=$(echo "$REL" | sed -n 's/^release:[[:space:]]*\(v[0-9]\+\.[0-9]\+\.[0-9]\+.*\)$/\1/p')
[[ -z "$VER" ]] && { echo "ERROR: cannot parse version from release subject"; exit 1; }
git tag --list "${VER}" >/dev/null || true
TAGGED=$(git tag --list "${VER}")
[[ -z "$TAGGED" ]] && { echo "ERROR: tag ${VER} not found"; exit 1; }
echo "OK: release tag ${VER} present"
