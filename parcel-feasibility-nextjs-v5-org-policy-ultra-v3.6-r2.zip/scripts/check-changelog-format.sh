#!/usr/bin/env bash
set -euo pipefail
FILE="CHANGELOG.md"; CFG="policy.changelog.json"
if [[ ! -f "$FILE" ]]; then echo "ERROR: CHANGELOG.md not found"; exit 1; fi
DATE_FMT=$(jq -r '.date_format // "YYYY.MM.DD"' "$CFG" 2>/dev/null || echo "YYYY.MM.DD")
CATS=$(jq -r '.categories[]' "$CFG" 2>/dev/null | paste -sd'|' - || echo "Breaking|UI|UX|Added|Changed|Fixed|Performance|Security|Docs|Chore")
DATE_RE='[0-9]{4}\.[0-9]{2}\.[0-9]{2}'
if ! head -n1 "$FILE" | grep -Eq '^# Changelog$'; then echo "ERROR: First line must be '# Changelog'"; exit 1; fi
LATEST=$(grep -nE "^## v[0-9]+\.[0-9]+\.[0-9]+ - ${DATE_RE}$" "$FILE" | head -n1 | cut -d: -f1 || true)
[[ -z "${LATEST:-}" ]] && { echo "ERROR: Missing '## vX.Y.Z - ${DATE_FMT}'"; exit 1; }
[[ $LATEST -gt 30 ]] && { echo "ERROR: Latest section must be within first 30 lines"; exit 1; }
awk -v start="$LATEST" 'NR>=start{print}' "$FILE" > ._tmp_ver.txt
LINE_NEXT=$(grep -nE '^## ' ._tmp_ver.txt | sed -n '2p' | cut -d: -f1 || true)
[[ -n "${LINE_NEXT:-}" ]] && head -n $((LINE_NEXT-1)) ._tmp_ver.txt > ._ver.txt || cp ._tmp_ver.txt ._ver.txt
if ! grep -Eq "^### (${CATS})$" ._ver.txt; then echo "ERROR: Missing category headings"; rm -f ._tmp_ver.txt ._ver.txt; exit 1; fi
python - "$CATS" <<'PY'
import re,sys
cats=set(sys.argv[1].split('|')); txt=open("._ver.txt","r",encoding="utf-8").read().splitlines()
ok=True; cur=None; has=False
for line in txt+["## END"]:
  m=re.match(r"^### (\S.*)$", line)
  if m:
    if cur is not None and not has: print(f"ERROR: Category '{cur}' has no bullet items."); ok=False
    cur=m.group(1).strip(); has=False; continue
  if line.startswith("### ") or line.startswith("## "): cur=None
  if cur and re.match(r"^\s*[-*+]\s+\S", line): has=True
if not ok: sys.exit(1)
PY
RC=$?; rm -f ._tmp_ver.txt ._ver.txt; exit $RC
