
module.exports = {
  rules: {
    'breaking-consistency': (parsed) => {
      const raw = String(parsed?.raw || '');
      const header = String(parsed?.header || '');
      const hasBang = /!:\s/.test(header);
      const hasFooter = /\nBREAKING CHANGE:\s.+/i.test(raw);
      if (!hasBang && !hasFooter) return [true];
      if (hasBang && hasFooter) return [true];
      if (hasBang && !hasFooter) return [false, "header has '!' but missing 'BREAKING CHANGE:' footer"];
      if (!hasBang && hasFooter) return [false, "footer has 'BREAKING CHANGE:' but header missing '!'"];
      return [true];
    },
    'scope-required-except-release': (p) => {
      const type = String(p?.type || '');
      const scope = String(p?.scope || '');
      if (type === 'release') return [true];
      return scope ? [true] : [false, 'scope is required for all types except release'];
    },
    'scope-dictionary': (p, when='always', allowed=[]) => {
      const scope = String(p?.scope || '');
      if (!scope || !Array.isArray(allowed) || allowed.length===0) return [true];
      const ok = allowed.some(x => {
        if (typeof x !== 'string') return false;
        if (x.endsWith('/*')) { const pref = x.slice(0,-1); return scope===pref.slice(0,-1) || scope.startsWith(pref); }
        return scope===x || scope.startsWith(x+'/');
      });
      return ok ? [true] : [false, `scope '${scope}' not in dictionary`];
    },
    'type-scope-map': (p, when='always', map={}) => {
      const type = String(p?.type || ''); const scope = String(p?.scope || '');
      const list = map?.[type]; if (!list) return [true];
      const allowEmpty = list.includes('');
      if (!scope) return allowEmpty ? [true] : [false, `type '${type}' requires a scope`];
      const ok = list.some(x => {
        if (typeof x !== 'string' || x==='') return false;
        const pref = x.endsWith('/*') ? x.slice(0,-1) : (x.endsWith('/') ? x : x+'/');
        return scope === pref.replace(/\/$/, '') || scope.startsWith(pref);
      });
      return ok ? [true] : [false, `type '${type}' not allowed for scope '${scope}'`];
    },
    'breaking-scope-only': (p, when='always', prefixes=[]) => {
      const header = String(p?.header || ''); const scope = String(p?.scope || '');
      const hasBang = /!:\s/.test(header); const hasFooter = /\nBREAKING CHANGE:\s.+/i.test(String(p?.raw||''));
      if (!hasBang && !hasFooter) return [true];
      if (!Array.isArray(prefixes) || prefixes.length===0) return [true];
      const norm = prefixes.map(q => q.endsWith('/*')? q.slice(0,-1): (q.endsWith('/')? q: q+'/'));
      const ok = norm.some(pref => scope === pref.replace(/\/$/, '') || scope.startsWith(pref));
      return ok ? [true] : [false, `BREAKING allowed only for scopes: ${norm.join(', ')}`];
    },
    'issue-key-footer-only': (p, when='always', cfg={}) => {
      const raw = String(p?.raw || ''); const header = String(p?.header || '');
      const keyRe = new RegExp((cfg && cfg.regex) || "\\b[A-Z][A-Z0-9]{1,9}-\\d{1,6}\\b");
      if (keyRe.test(header)) return [false, 'issue key must not appear in subject; put it in footer'];
      const lines = raw.split(/\r?\n/); const footers = []; const body=[];
      lines.forEach(line => { const m=line.match(/^([A-Za-z가-힣-]+):\s*(.+)$/); if (m) footers.push({k:m[1],v:m[2]}); else body.push(line); });
      if (body.some(l => keyRe.test(l))) return [false, 'issue key must not appear in body; put it in footer'];
      const prefixes = (cfg && cfg.footer_prefixes) || ['JIRA','Closes','Fixes','Resolves','Refs','이슈','닫음','해결'];
      const ok = footers.some(({k,v}) => prefixes.includes(k) && keyRe.test(v));
      return ok ? [true] : [false, 'missing issue key in footer (e.g., JIRA: PROJ-123)'];
    },
  },
};
